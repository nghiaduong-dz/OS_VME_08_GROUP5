/*
 * ================================================================
 *  VIRTUAL MEMORY PAGE REPLACEMENT SIMULATOR
 *  OS_VME_08 - GROUP 5
 *  Truong Dai hoc Giao thong Van tai TP.HCM (HCMUTRANS)
 *  Mon hoc: He Dieu Hanh | Ma lop: 7480201390613
 * ================================================================
 *  Thanh vien nhom:
 *   1. Phan Dinh Phat        060206002816  Algorithm Developer
 *   2. Nguyen Thi Xuan Tuyen 054306001845  Data & File Handler
 *   3. Nguyen Thanh Tuan     051206002660  GUI Developer
 *   4. Duong Trong Nghia     066206008908  Tester & Integrator
 *   5. Kim Nhut Hoang        084206006510  Documentation
 * ================================================================
 *  Thuat toan: FIFO | LRU | OPT
 *  Tham khao:  Operating System Concepts - 10th Edition
 *  Build:      Visual Studio 2022 | C++17 | Windows x64
 * ================================================================
 */

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>
#include <chrono>
#include <climits>
#include <ctime>

using namespace std;

// ================================================================
//  CONSTANTS
// ================================================================
const int STRESS_THRESHOLD = 1000;
const string VERSION = "1.0.0";

// ================================================================
//  WINDOWS CONSOLE COLOR
// ================================================================
enum Color {
    BLACK = 0, BLUE = 9, GREEN = 10, CYAN = 11,
    RED = 12, MAGENTA = 13, YELLOW = 14, WHITE = 15,
    GRAY = 8, DARK_GREEN = 2, DARK_CYAN = 3
};

static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

static void setColor(int fg, int bg = 0) {
    SetConsoleTextAttribute(hConsole, (WORD)(bg * 16 + fg));
}
static void reset() { setColor(WHITE); }

static void print(const string& s, int fg, int bg = 0) {
    setColor(fg, bg); cout << s; reset();
}

// ================================================================
//  STEP RECORD
// ================================================================
struct Step {
    int          page;
    vector<int>  frames;   // -1 = empty
    bool         isFault;
    int          totalFaults;
    int          evicted;  // page evicted (-1 if none)
};

// ================================================================
//  FILE HANDLER
//  - Doc input CSV: dong 1 = frame size, dong 2 = reference string
//  - Xuat output CSV: step-by-step report
// ================================================================
class FileHandler {
public:
    static bool readInput(const string& path, int& frameSize, vector<int>& refString) {
        ifstream file(path);
        if (!file.is_open()) {
            print("[FileHandler] ERROR: Khong mo duoc file: " + path + "\n", RED);
            return false;
        }
        string line1, line2;
        if (!getline(file, line1)) {
            print("[FileHandler] ERROR: File trong hoac thieu dong frame size.\n", RED);
            return false;
        }
        // Trim BOM if present
        if (line1.size() >= 3 &&
            (unsigned char)line1[0] == 0xEF &&
            (unsigned char)line1[1] == 0xBB &&
            (unsigned char)line1[2] == 0xBF)
            line1 = line1.substr(3);
        line1.erase(remove_if(line1.begin(), line1.end(), ::isspace), line1.end());

        try { frameSize = stoi(line1); }
        catch (...) {
            print("[FileHandler] ERROR: Frame size khong hop le.\n", RED);
            return false;
        }
        if (frameSize <= 0 || frameSize > 20) {
            print("[FileHandler] ERROR: Frame size phai tu 1 den 20 (got " + to_string(frameSize) + ").\n", RED);
            return false;
        }
        if (!getline(file, line2)) {
            print("[FileHandler] ERROR: Thieu dong reference string.\n", RED);
            return false;
        }
        refString.clear();
        stringstream ss(line2);
        string token;
        int skipped = 0;
        while (getline(ss, token, ',')) {
            token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
            if (token.empty()) continue;
            try {
                int val = stoi(token);
                if (val < 0) { skipped++; continue; }
                refString.push_back(val);
            } catch (...) { skipped++; }
        }
        if (skipped > 0)
            print("[FileHandler] WARNING: " + to_string(skipped) + " token khong hop le bi bo qua.\n", YELLOW);
        if (refString.empty()) {
            print("[FileHandler] ERROR: Khong co page nao hop le.\n", RED);
            return false;
        }
        file.close();
        return true;
    }

    static bool writeOutput(const string& path, const string& algoName,
                            int frameSize, const vector<int>& refString,
                            const vector<Step>& steps, double execTimeMs, bool stressMode)
    {
        ofstream file(path);
        if (!file.is_open()) {
            print("[FileHandler] ERROR: Khong ghi duoc file: " + path + "\n", RED);
            return false;
        }

        int faults = 0, hits = 0;
        for (const auto& s : steps) { if (s.isFault) faults++; else hits++; }
        double hitRate  = steps.empty() ? 0.0 : (double)hits   / steps.size() * 100.0;
        double faultRate= steps.empty() ? 0.0 : (double)faults / steps.size() * 100.0;

        // Header
        file << "=== VIRTUAL MEMORY PAGE REPLACEMENT SIMULATOR ===\n";
        file << "OS_VME_08 - Group 5 - HCMUTRANS\n\n";
        file << "Algorithm," << algoName << "\n";
        file << "Frame Size," << frameSize << "\n";
        file << "Total References," << refString.size() << "\n";
        file << fixed << setprecision(2);
        file << "Total Faults,"   << faults    << "\n";
        file << "Total Hits,"     << hits      << "\n";
        file << "Hit Rate (%),"   << hitRate   << "\n";
        file << "Fault Rate (%)," << faultRate << "\n";
        file << "Exec Time (ms)," << execTimeMs << "\n";

        // Reference string
        file << "\nReference String,";
        for (int i = 0; i < (int)refString.size(); i++) {
            file << refString[i];
            if (i < (int)refString.size() - 1) file << " ";
        }
        file << "\n";

        if (stressMode) {
            file << "\n[STRESS MODE] Step report omitted (>" << STRESS_THRESHOLD << " references)\n";
            file << "Only analytics exported to protect RAM.\n";
        } else {
            // Column header
            file << "\nStep,Page,Fault/Hit,Evicted";
            for (int i = 1; i <= frameSize; i++) file << ",Frame_" << i;
            file << ",Total_Faults,Total_Hits\n";

            int totalH = 0, totalF = 0;
            for (int i = 0; i < (int)steps.size(); i++) {
                const Step& s = steps[i];
                if (s.isFault) totalF++; else totalH++;
                file << (i + 1) << ",";
                file << s.page << ",";
                file << (s.isFault ? "FAULT" : "HIT") << ",";
                file << (s.evicted >= 0 ? to_string(s.evicted) : "-");
                for (int f = 0; f < frameSize; f++) {
                    if (f < (int)s.frames.size() && s.frames[f] != -1)
                        file << "," << s.frames[f];
                    else
                        file << ",-";
                }
                file << "," << totalF << "," << totalH << "\n";
            }
        }
        file.close();
        return true;
    }

    static void createSampleInput(const string& path) {
        ofstream f(path);
        f << "3\n";
        f << "7,0,1,2,0,3,0,4,2,3,0,3\n";
        f.close();
    }

    static void createBeladyInput(const string& path) {
        ofstream f(path);
        f << "4\n";
        f << "1,2,3,4,1,2,5,1,2,3,4,5\n";
        f.close();
    }
};

// ================================================================
//  ALGORITHM ENGINE
//  FIFO | LRU | OPT
//  Ket qua khop voi giao trinh OS Concepts 10th Edition
// ================================================================
class AlgorithmEngine {
public:

    // ---- FIFO --------------------------------------------------
    static vector<Step> runFIFO(const vector<int>& refs, int n) {
        vector<Step> steps;
        vector<int>  frames(n, -1);
        vector<int>  queue;   // slot order (FIFO)
        int faultCount = 0;

        for (int page : refs) {
            bool hit = find(frames.begin(), frames.end(), page) != frames.end();
            Step s;
            s.page = page; s.isFault = !hit; s.evicted = -1;

            if (!hit) {
                faultCount++;
                bool placed = false;
                for (int i = 0; i < n; i++) {
                    if (frames[i] == -1) {
                        frames[i] = page;
                        queue.push_back(i);
                        placed = true; break;
                    }
                }
                if (!placed) {
                    int slot = queue.front(); queue.erase(queue.begin());
                    s.evicted = frames[slot];
                    frames[slot] = page;
                    queue.push_back(slot);
                }
            }
            s.frames = frames; s.totalFaults = faultCount;
            steps.push_back(s);
        }
        return steps;
    }

    // ---- LRU ---------------------------------------------------
    static vector<Step> runLRU(const vector<int>& refs, int n) {
        vector<Step> steps;
        vector<int>  frames(n, -1);
        vector<int>  lastUsed(n, -1);
        int faultCount = 0;

        for (int i = 0; i < (int)refs.size(); i++) {
            int page = refs[i];
            int hitSlot = -1;
            for (int f = 0; f < n; f++) if (frames[f] == page) { hitSlot = f; break; }
            bool hit = (hitSlot != -1);
            Step s; s.page = page; s.isFault = !hit; s.evicted = -1;

            if (hit) {
                lastUsed[hitSlot] = i;
            } else {
                faultCount++;
                int targetSlot = -1;
                for (int f = 0; f < n; f++) if (frames[f] == -1) { targetSlot = f; break; }
                if (targetSlot == -1) {
                    int minTime = INT_MAX, minSlot = 0;
                    for (int f = 0; f < n; f++)
                        if (lastUsed[f] < minTime) { minTime = lastUsed[f]; minSlot = f; }
                    targetSlot = minSlot;
                }
                s.evicted = frames[targetSlot];
                frames[targetSlot] = page;
                lastUsed[targetSlot] = i;
            }
            s.frames = frames; s.totalFaults = faultCount;
            steps.push_back(s);
        }
        return steps;
    }

    // ---- OPT ---------------------------------------------------
    static vector<Step> runOPT(const vector<int>& refs, int n) {
        vector<Step> steps;
        vector<int>  frames(n, -1);
        int faultCount = 0;

        for (int i = 0; i < (int)refs.size(); i++) {
            int page = refs[i];
            bool hit = find(frames.begin(), frames.end(), page) != frames.end();
            Step s; s.page = page; s.isFault = !hit; s.evicted = -1;

            if (!hit) {
                faultCount++;
                int targetSlot = -1;
                for (int f = 0; f < n; f++) if (frames[f] == -1) { targetSlot = f; break; }
                if (targetSlot == -1) {
                    int farthest = -1;
                    for (int f = 0; f < n; f++) {
                        int nxt = INT_MAX;
                        for (int j = i + 1; j < (int)refs.size(); j++)
                            if (refs[j] == frames[f]) { nxt = j; break; }
                        if (nxt > farthest) { farthest = nxt; targetSlot = f; }
                    }
                }
                s.evicted = frames[targetSlot];
                frames[targetSlot] = page;
            }
            s.frames = frames; s.totalFaults = faultCount;
            steps.push_back(s);
        }
        return steps;
    }

    static int countFaults(const vector<Step>& steps) {
        int c = 0;
        for (const auto& s : steps) if (s.isFault) c++;
        return c;
    }
};

// ================================================================
//  DISPLAY / GUI
// ================================================================
class Display {
    int n; // frame size
public:
    Display(int fs) : n(fs) {}

    // ---- Banner ------------------------------------------------
    void banner() const {
        cout << "\n";
        print("  ╔══════════════════════════════════════════════════════════╗\n", CYAN);
        print("  ║                                                          ║\n", CYAN);
        print("  ║    VIRTUAL MEMORY PAGE REPLACEMENT SIMULATOR  v" + VERSION + "   ║\n", CYAN);
        print("  ║    OS_VME_08 - Nhom 5 - HCMUTRANS                       ║\n", CYAN);
        print("  ║                                                          ║\n", CYAN);
        print("  ║  Thuat toan: FIFO  |  LRU  |  OPT (Optimal)             ║\n", CYAN);
        print("  ║  Ref: OS Concepts 10th Ed. - Silberschatz et al.         ║\n", CYAN);
        print("  ║                                                          ║\n", CYAN);
        print("  ╚══════════════════════════════════════════════════════════╝\n", CYAN);
        cout << "\n";
    }

    // ---- Info --------------------------------------------------
    void showInfo(const vector<int>& refs) const {
        print("  ┌─ Input ──────────────────────────────────────────────────\n", GRAY);

        print("  │ Frame size    : ", GRAY);
        print(to_string(n), YELLOW); cout << " frames\n";

        print("  │ Ref length    : ", GRAY);
        print(to_string(refs.size()), YELLOW); cout << " pages\n";

        print("  │ Ref string    : ", GRAY);
        int show = (int)refs.size() > 25 ? 25 : (int)refs.size();
        for (int i = 0; i < show; i++) {
            print(to_string(refs[i]), CYAN);
            if (i < show - 1) cout << " ";
        }
        if ((int)refs.size() > 25) print("  ... +" + to_string((int)refs.size()-25) + " more", GRAY);
        cout << "\n";

        print("  └──────────────────────────────────────────────────────────\n", GRAY);
        cout << "\n";
    }

    // ---- Gantt Table -------------------------------------------
    void gantt(const string& algoName, const vector<Step>& steps, int fg) const {
        int total = (int)steps.size();
        int show  = total < 30 ? total : 30;

        // Title
        cout << "\n  ";
        print(" " + algoName + " ", fg, 0);
        print("  Gantt Chart", WHITE);
        if (total > 30) print("  (hien thi 30/" + to_string(total) + " buoc)", GRAY);
        cout << "\n\n";

        // Column numbers
        cout << "  ";
        print("Step     ", GRAY);
        for (int i = 0; i < show; i++) {
            setColor(GRAY); cout << setw(3) << (i+1);
        }
        reset(); cout << "\n";

        // Separator
        cout << "  ";
        print("─────────", GRAY);
        for (int i = 0; i < show; i++) print("───", GRAY);
        cout << "\n";

        // Page row
        cout << "  ";
        print("Page     ", WHITE);
        for (int i = 0; i < show; i++) {
            const Step& s = steps[i];
            if (s.isFault) setColor(RED); else setColor(GREEN);
            cout << setw(3) << s.page;
        }
        reset(); cout << "\n";

        // Separator
        cout << "  ";
        print("─────────", GRAY);
        for (int i = 0; i < show; i++) print("───", GRAY);
        cout << "\n";

        // Frame rows
        for (int f = 0; f < n; f++) {
            cout << "  ";
            print("Frame " + to_string(f+1) + "  ", GRAY);
            for (int i = 0; i < show; i++) {
                const Step& s = steps[i];
                if (f < (int)s.frames.size() && s.frames[f] != -1) {
                    bool isNew = s.isFault && s.frames[f] == s.page;
                    if (isNew) setColor(BLUE);
                    else       setColor(WHITE);
                    cout << setw(3) << s.frames[f];
                    reset();
                } else {
                    setColor(GRAY); cout << "  ·"; reset();
                }
            }
            cout << "\n";
        }

        // Separator
        cout << "  ";
        print("─────────", GRAY);
        for (int i = 0; i < show; i++) print("───", GRAY);
        cout << "\n";

        // F/H indicator row
        cout << "  ";
        print("F/H      ", GRAY);
        for (int i = 0; i < show; i++) {
            if (steps[i].isFault) { setColor(RED);   cout << "  F"; }
            else                  { setColor(GREEN);  cout << "  H"; }
            reset();
        }
        cout << "\n\n";

        // Stats box
        int faults = AlgorithmEngine::countFaults(steps);
        int hits   = total - faults;
        double hr  = (double)hits / total * 100.0;

        print("  ┌─ " + algoName + " Result ─────────────────────────────────────\n", fg);
        print("  │  Page faults  : ", GRAY); print(to_string(faults), RED);
        cout << " / " << total << " references\n";
        print("  │  Page hits    : ", GRAY); print(to_string(hits), GREEN);
        cout << "\n";
        print("  │  Hit rate     : ", GRAY);
        print(to_string((int)hr) + "." + to_string((int)(hr*10)%10) + "%", CYAN);
        cout << "\n";
        print("  └────────────────────────────────────────────────────────\n", fg);
        cout << "\n";
    }

    // ---- Comparison --------------------------------------------
    void compare(int fifoF, int lruF, int optF, int total,
                 double fifoMs, double lruMs, double optMs) const
    {
        cout << "\n";
        print("  ╔═══════════════════════════════════════════════════════╗\n", CYAN);
        print("  ║           SO SANH 3 THUAT TOAN                       ║\n", CYAN);
        print("  ╚═══════════════════════════════════════════════════════╝\n", CYAN);
        cout << "\n";

        int maxF = fifoF;
        if (lruF > maxF) maxF = lruF;
        if (optF > maxF) maxF = optF;

        struct AlgoInfo { string name; int faults; double ms; int fg; };
        vector<AlgoInfo> algos = {
            {"FIFO", fifoF, fifoMs, BLUE},
            {"LRU ", lruF,  lruMs,  GREEN},
            {"OPT ", optF,  optMs,  MAGENTA}
        };

        for (auto& a : algos) {
            int barLen = maxF > 0 ? (a.faults * 24 / maxF) : 0;
            int hits   = total - a.faults;
            double hr  = (double)hits / total * 100.0;

            cout << "  ";
            print(a.name, a.fg);
            cout << " │";
            setColor(a.fg);
            for (int i = 0; i < barLen; i++) cout << "█";
            reset();
            setColor(GRAY);
            for (int i = barLen; i < 24; i++) cout << "░";
            reset();
            cout << "│ ";
            print(to_string(a.faults) + " faults", RED);
            cout << "  ";
            print(to_string(hits) + " hits", GREEN);
            cout << "  ";

            // Hit rate
            setColor(CYAN);
            cout << fixed << setprecision(1) << hr << "%";
            reset();
            cout << "  ";
            setColor(GRAY);
            cout << fixed << setprecision(3) << a.ms << "ms";
            reset();
            cout << "\n";
        }

        // Winner
        int best = fifoF;
        if (lruF < best) best = lruF;
        if (optF < best) best = optF;

        cout << "\n  ";
        print("  Thuat toan tot nhat: ", WHITE);
        if (optF == best && optF <= lruF && optF <= fifoF)
            print("OPT", MAGENTA);
        else if (lruF == best && lruF <= fifoF)
            print("LRU", GREEN);
        else
            print("FIFO", BLUE);
        print("  (" + to_string(best) + " page faults)", YELLOW);
        cout << "\n";

        // Belady note
        if (fifoF > lruF || fifoF > optF) {
            cout << "\n  ";
            print("  [!] FIFO co the gap hien tuong Belady Anomaly", YELLOW);
            cout << "\n";
        }
        cout << "\n";
    }

    // ---- Menu --------------------------------------------------
    void menu() const {
        print("  ╔═══════════════════════════════════════════════════════╗\n", DARK_CYAN);
        print("  ║  MENU                                                 ║\n", DARK_CYAN);
        print("  ╠═══════════════════════════════════════════════════════╣\n", DARK_CYAN);
        print("  ║  [1]  Chay thuat toan FIFO                            ║\n", WHITE);
        print("  ║  [2]  Chay thuat toan LRU                             ║\n", WHITE);
        print("  ║  [3]  Chay thuat toan OPT (Optimal)                   ║\n", WHITE);
        print("  ║  [4]  Chay CA 3 thuat toan va so sanh                 ║\n", YELLOW);
        print("  ╠═══════════════════════════════════════════════════════╣\n", DARK_CYAN);
        print("  ║  [5]  Tai file CSV moi                                ║\n", WHITE);
        print("  ║  [6]  Xuat ket qua ra output/output.csv               ║\n", WHITE);
        print("  ║  [7]  Hien thi thong tin nhom                         ║\n", WHITE);
        print("  ╠═══════════════════════════════════════════════════════╣\n", DARK_CYAN);
        print("  ║  [0]  Thoat                                           ║\n", GRAY);
        print("  ╚═══════════════════════════════════════════════════════╝\n", DARK_CYAN);
        cout << "\n";
        print("  Lua chon: ", YELLOW);
    }

    // ---- Team Info ---------------------------------------------
    void teamInfo() const {
        cout << "\n";
        print("  ╔═══════════════════════════════════════════════════════════╗\n", CYAN);
        print("  ║  THONG TIN NHOM 5 - OS_VME_08                            ║\n", CYAN);
        print("  ╠═══════════════════════════════════════════════════════════╣\n", CYAN);
        print("  ║  Truong: Dai hoc Giao thong Van tai TP.HCM               ║\n", WHITE);
        print("  ║  Mon:    He Dieu Hanh | Ma lop: 7480201390613            ║\n", WHITE);
        print("  ╠═══════════════════════════════════════════════════════════╣\n", CYAN);
        print("  ║  1. Phan Dinh Phat        060206002816                   ║\n", YELLOW);
        print("  ║     -> Algorithm Developer: FIFO, LRU, OPT               ║\n", GRAY);
        print("  ║  2. Nguyen Thi Xuan Tuyen 054306001845                   ║\n", YELLOW);
        print("  ║     -> Data & File Handler: CSV input/output             ║\n", GRAY);
        print("  ║  3. Nguyen Thanh Tuan     051206002660                   ║\n", YELLOW);
        print("  ║     -> GUI Developer: Console UI & display               ║\n", GRAY);
        print("  ║  4. Duong Trong Nghia     066206008908                   ║\n", YELLOW);
        print("  ║     -> Tester & Integrator: Debug, demo video            ║\n", GRAY);
        print("  ║  5. Kim Nhut Hoang        084206006510                   ║\n", YELLOW);
        print("  ║     -> Documentation: Report & slides                    ║\n", GRAY);
        print("  ╠═══════════════════════════════════════════════════════════╣\n", CYAN);
        print("  ║  Ref: OS Concepts 10th Ed. - Silberschatz et al.         ║\n", DARK_GREEN);
        print("  ╚═══════════════════════════════════════════════════════════╝\n", CYAN);
        cout << "\n";
    }
};

// ================================================================
//  MAIN
// ================================================================
int main() {
    SetConsoleOutputCP(CP_UTF8);
    // Maximize console window
    HWND hwnd = GetConsoleWindow();
    if (hwnd) ShowWindow(hwnd, SW_MAXIMIZE);

    int          frameSize = 3;
    vector<int>  refString;
    vector<Step> lastSteps;
    string       lastAlgo  = "";
    double       lastExecMs = 0.0;

    string inputPath  = "input/input.csv";
    string outputPath = "output/output.csv";

    // Create sample CSVs if not present
    {
        ifstream t1(inputPath);
        if (!t1.is_open()) FileHandler::createSampleInput(inputPath);
        ifstream t2("input/belady_test.csv");
        if (!t2.is_open()) FileHandler::createBeladyInput("input/belady_test.csv");
    }

    if (!FileHandler::readInput(inputPath, frameSize, refString)) {
        print("[Info] Dung chuoi mac dinh.\n", YELLOW);
        frameSize = 3;
        refString = {7,0,1,2,0,3,0,4,2,3,0,3};
    }

    Display disp(frameSize);
    disp.banner();
    disp.showInfo(refString);

    bool running = true;
    while (running) {
        disp.menu();
        int choice = 0;
        cin >> choice;
        cout << "\n";

        bool stress = (int)refString.size() > STRESS_THRESHOLD;

        switch (choice) {

        case 1: {
            print("  >> Dang chay FIFO...\n", YELLOW);
            auto t0 = chrono::high_resolution_clock::now();
            lastSteps  = AlgorithmEngine::runFIFO(refString, frameSize);
            auto t1    = chrono::high_resolution_clock::now();
            lastExecMs = chrono::duration<double,milli>(t1-t0).count();
            lastAlgo   = "FIFO";
            if (!stress) disp.gantt("FIFO", lastSteps, BLUE);
            else {
                int f = AlgorithmEngine::countFaults(lastSteps);
                print("  [STRESS] FIFO: ", YELLOW);
                print(to_string(f) + " faults", RED);
                cout << " | ";
                print(to_string((int)refString.size()-f) + " hits", GREEN);
                cout << " | " << fixed << setprecision(3) << lastExecMs << " ms\n\n";
            }
            break;
        }

        case 2: {
            print("  >> Dang chay LRU...\n", YELLOW);
            auto t0 = chrono::high_resolution_clock::now();
            lastSteps  = AlgorithmEngine::runLRU(refString, frameSize);
            auto t1    = chrono::high_resolution_clock::now();
            lastExecMs = chrono::duration<double,milli>(t1-t0).count();
            lastAlgo   = "LRU";
            if (!stress) disp.gantt("LRU", lastSteps, GREEN);
            else {
                int f = AlgorithmEngine::countFaults(lastSteps);
                print("  [STRESS] LRU:  ", YELLOW);
                print(to_string(f) + " faults", RED);
                cout << " | ";
                print(to_string((int)refString.size()-f) + " hits", GREEN);
                cout << " | " << fixed << setprecision(3) << lastExecMs << " ms\n\n";
            }
            break;
        }

        case 3: {
            print("  >> Dang chay OPT...\n", YELLOW);
            auto t0 = chrono::high_resolution_clock::now();
            lastSteps  = AlgorithmEngine::runOPT(refString, frameSize);
            auto t1    = chrono::high_resolution_clock::now();
            lastExecMs = chrono::duration<double,milli>(t1-t0).count();
            lastAlgo   = "OPT";
            if (!stress) disp.gantt("OPT", lastSteps, MAGENTA);
            else {
                int f = AlgorithmEngine::countFaults(lastSteps);
                print("  [STRESS] OPT:  ", YELLOW);
                print(to_string(f) + " faults", RED);
                cout << " | ";
                print(to_string((int)refString.size()-f) + " hits", GREEN);
                cout << " | " << fixed << setprecision(3) << lastExecMs << " ms\n\n";
            }
            break;
        }

        case 4: {
            print("  >> Dang chay ca 3 thuat toan...\n\n", YELLOW);
            auto t0 = chrono::high_resolution_clock::now();
            auto sF = AlgorithmEngine::runFIFO(refString, frameSize);
            auto t1 = chrono::high_resolution_clock::now();
            auto sL = AlgorithmEngine::runLRU(refString, frameSize);
            auto t2 = chrono::high_resolution_clock::now();
            auto sO = AlgorithmEngine::runOPT(refString, frameSize);
            auto t3 = chrono::high_resolution_clock::now();

            double msF = chrono::duration<double,milli>(t1-t0).count();
            double msL = chrono::duration<double,milli>(t2-t1).count();
            double msO = chrono::duration<double,milli>(t3-t2).count();

            if (!stress) {
                disp.gantt("FIFO", sF, BLUE);
                disp.gantt("LRU",  sL, GREEN);
                disp.gantt("OPT",  sO, MAGENTA);
            }
            disp.compare(
                AlgorithmEngine::countFaults(sF),
                AlgorithmEngine::countFaults(sL),
                AlgorithmEngine::countFaults(sO),
                (int)refString.size(), msF, msL, msO
            );
            lastSteps = sO; lastAlgo = "OPT"; lastExecMs = msO;
            break;
        }

        case 5: {
            cout << "  Nhap duong dan CSV (Enter = dung 'input/input.csv'): ";
            string path;
            cin.ignore();
            getline(cin, path);
            if (path.empty()) path = inputPath;
            int fs; vector<int> rs;
            if (FileHandler::readInput(path, fs, rs)) {
                frameSize = fs; refString = rs;
                disp = Display(frameSize);
                print("  Da tai thanh cong!\n\n", GREEN);
                disp.showInfo(refString);
            }
            break;
        }

        case 6: {
            if (lastSteps.empty()) {
                print("  Chua co ket qua. Hay chay mot thuat toan truoc.\n\n", YELLOW);
            } else {
                bool so = (int)refString.size() > STRESS_THRESHOLD;
                if (FileHandler::writeOutput(outputPath, lastAlgo, frameSize,
                                             refString, lastSteps, lastExecMs, so))
                    print("  Da xuat ra: " + outputPath + "\n\n", GREEN);
            }
            break;
        }

        case 7:
            disp.teamInfo();
            break;

        case 0:
            running = false;
            cout << "\n";
            print("  Cam on da su dung! - Nhom 5 HCMUTRANS\n\n", CYAN);
            break;

        default:
            print("  Lua chon khong hop le. Vui long thu lai.\n\n", RED);
        }
    }
    return 0;
}
