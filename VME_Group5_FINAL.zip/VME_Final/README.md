# VME_Group5 - Virtual Memory Page Replacement Simulator
## OS_VME_08 | Nhóm 5 | HCMUTRANS | C++17 | Visual Studio 2022

---

## Cách mở và chạy (QUAN TRỌNG)

1. Giải nén ZIP ra một thư mục bất kỳ
2. Double-click **`VME_Group5.sln`**
3. Nếu VS hỏi Retarget → chọn **"Retarget to v145 (Latest)"** → OK
4. Nhấn **Ctrl + Shift + B** → chờ "Build: 1 succeeded"
5. Nhấn **Ctrl + F5** → chương trình chạy

---

## Menu chương trình

| Phím | Chức năng |
|---|---|
| 1 | Chạy FIFO + hiển thị Gantt chart |
| 2 | Chạy LRU + hiển thị Gantt chart |
| 3 | Chạy OPT + hiển thị Gantt chart |
| 4 | Chạy CẢ 3 + so sánh trực quan |
| 5 | Tải file CSV khác |
| 6 | Xuất kết quả ra output/output.csv |
| 7 | Thông tin nhóm |
| 0 | Thoát |

---

## Màu sắc trong Gantt chart

| Màu | Ý nghĩa |
|---|---|
| Đỏ | Page Fault (F) |
| Xanh lá | Page Hit (H) |
| Xanh dương | Frame vừa được nạp trang mới |
| Xám | Ô trống |

---

## File CSV đầu vào

**Dòng 1:** Số khung trang (1–20)
**Dòng 2:** Chuỗi tham chiếu, phân cách bằng dấu phẩy

```
3
7,0,1,2,0,3,0,4,2,3,0,3
```

---

## File test có sẵn trong thư mục input/

| File | Mô tả |
|---|---|
| input.csv | Ví dụ chuẩn từ giáo trình OS Concepts 10e |
| belady_test.csv | Kiểm tra hiện tượng Bélady's Anomaly |
| stress_test.csv | 100 trang ngẫu nhiên (kiểm thử hiệu năng) |

---

## Thành viên nhóm 5

| Họ tên | MSSV | Nhiệm vụ |
|---|---|---|
| Phan Đình Phát | 060206002816 | Algorithm Developer |
| Nguyễn Thị Xuân Tuyền | 054306001845 | Data & File Handler |
| Nguyễn Thanh Tuấn | 051206002660 | GUI Developer |
| Dương Trọng Nghĩa | 066206008908 | Tester & Integrator |
| Kim Nhựt Hoàng | 084206006510 | Documentation |
