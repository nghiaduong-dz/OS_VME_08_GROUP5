# OS_VME_08_GROUP5 — Virtual Memory Page Replacement Simulator

> **Môn:** Hệ Điều Hành | **Lớp:** 7480201390613 | **Nhóm:** 5  
> **Trường:** Đại học Giao thông Vận tải TP.HCM (HCMUTRANS)

---

## Yêu cầu đề bài đã đáp ứng

| Yêu cầu | Trạng thái |
|---|---|
| GUI application chạy trên Windows | ✅ Python tkinter |
| Ngôn ngữ: C#, C++, Python, Java | ✅ Python 3 |
| Chạy không lỗi / exception | ✅ Full error handling |
| Kết quả đúng, so sánh với giáo trình | ✅ Proof tab + Unit tests |
| Dùng CSV làm input | ✅ FileHandler đọc/ghi CSV |
| Tự định nghĩa input theo project | ✅ Load CSV tùy ý |

---

## Cách chạy

### Yêu cầu
- Python 3.8+ (tkinter có sẵn, không cần cài thêm)

### Chạy
```bash
python main.py
```

Hoặc double-click `run.bat` trên Windows.

---

## Cấu trúc thư mục

```
Code/
├── main.py                  ← Toàn bộ ứng dụng GUI
├── run.bat                  ← Double-click để chạy trên Windows
├── input/
│   ├── input.csv            ← Ví dụ chuẩn từ giáo trình (3 frames)
│   ├── belady_test.csv      ← Kiểm tra Bélady's Anomaly (4 frames)
│   └── stress_test.csv      ← 100 trang ngẫu nhiên
└── output/
    └── (kết quả CSV xuất ra)
```

---

## Tính năng GUI

| Tab | Nội dung |
|---|---|
| Gantt Chart | Bảng trạng thái frame từng bước, màu sắc rõ ràng |
| Comparison | So sánh 3 thuật toán, bar chart, bảng thống kê |
| Statistics | Proof vs giáo trình, thống kê chi tiết |

---

## Định dạng CSV đầu vào

```
3
7,0,1,2,0,3,0,4,2,3,0,3
```
- Dòng 1: Frame size (1–20)
- Dòng 2: Reference string, phân cách bằng dấu phẩy

---

## Kiểm chứng với giáo trình OS Concepts 10th Edition

| Thuật toán | Kết quả giáo trình | Kết quả app |
|---|---|---|
| FIFO | 9 page faults | 9 ✅ |
| LRU | 8 page faults | 8 ✅ |
| OPT | 6 page faults | 6 ✅ |

---

## Thành viên nhóm 5

| Họ tên | MSSV | Nhiệm vụ |
|---|---|---|
| Phan Đình Phát | 060206002816 | Algorithm Developer |
| Nguyễn Thị Xuân Tuyền | 054306001845 | Data & File Handler |
| Nguyễn Thanh Tuấn | 051206002660 | GUI Developer |
| Dương Trọng Nghĩa | 066206008908 | Tester & Integrator |
| Kim Nhựt Hoàng | 084206006510 | Documentation |
