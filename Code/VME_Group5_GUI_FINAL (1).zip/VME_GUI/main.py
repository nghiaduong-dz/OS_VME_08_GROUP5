"""
================================================================
  VIRTUAL MEMORY PAGE REPLACEMENT SIMULATOR
  OS_VME_08 - GROUP 5
  Truong Dai hoc Giao thong Van tai TP.HCM (HCMUTRANS)
  Mon hoc: He Dieu Hanh | Ma lop: 7480201390613
================================================================
  Thanh vien nhom:
   1. Phan Dinh Phat        060206002816  Algorithm Developer
   2. Nguyen Thi Xuan Tuyen 054306001845  Data & File Handler
   3. Nguyen Thanh Tuan     051206002660  GUI Developer
   4. Duong Trong Nghia     066206008908  Tester & Integrator
   5. Kim Nhut Hoang        084206006510  Documentation
================================================================
  Ngon ngu: Python 3.x + tkinter (built-in, khong can cai them)
  Chay:     python main.py
  Ref:      OS Concepts 10th Ed. - Silberschatz et al.
================================================================
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import csv
import os
import time


# ================================================================
#  MODELS
# ================================================================
class Step:
    def __init__(self, page, frames, is_fault, total_faults, evicted=-1):
        self.page         = page
        self.frames       = list(frames)   # list, -1 = trong
        self.is_fault     = is_fault
        self.total_faults = total_faults
        self.evicted      = evicted        # trang bi day ra


# ================================================================
#  ALGORITHMS
# ================================================================
class FIFO:
    @staticmethod
    def run(refs, n):
        steps   = []
        frames  = [-1] * n
        queue   = []          # luu index slot theo thu tu FIFO
        faults  = 0

        for page in refs:
            hit = page in frames
            evicted = -1

            if not hit:
                faults += 1
                if -1 in frames:
                    slot = frames.index(-1)
                    frames[slot] = page
                    queue.append(slot)
                else:
                    slot = queue.pop(0)
                    evicted = frames[slot]
                    frames[slot] = page
                    queue.append(slot)

            steps.append(Step(page, frames, not hit, faults, evicted))

        return steps

    @staticmethod
    def count_faults(steps):
        return sum(1 for s in steps if s.is_fault)


class LRU:
    @staticmethod
    def run(refs, n):
        steps    = []
        frames   = [-1] * n
        last_used = [-1] * n   # buoc cuoi dung moi slot
        faults   = 0

        for i, page in enumerate(refs):
            hit_slot = next((f for f in range(n) if frames[f] == page), -1)
            hit = hit_slot != -1
            evicted = -1

            if hit:
                last_used[hit_slot] = i
            else:
                faults += 1
                if -1 in frames:
                    slot = frames.index(-1)
                else:
                    slot = last_used.index(min(last_used))
                evicted = frames[slot]
                frames[slot] = page
                last_used[slot] = i

            steps.append(Step(page, frames, not hit, faults, evicted))

        return steps

    @staticmethod
    def count_faults(steps):
        return sum(1 for s in steps if s.is_fault)


class OPT:
    @staticmethod
    def run(refs, n):
        steps  = []
        frames = [-1] * n
        faults = 0

        for i, page in enumerate(refs):
            hit = page in frames
            evicted = -1

            if not hit:
                faults += 1
                if -1 in frames:
                    slot = frames.index(-1)
                else:
                    # Tim trang dung xa nhat trong tuong lai
                    farthest, slot = -1, 0
                    for f in range(n):
                        future = next(
                            (j for j in range(i+1, len(refs)) if refs[j] == frames[f]),
                            len(refs)  # khong con dung nua -> uu tien day
                        )
                        if future > farthest:
                            farthest, slot = future, f
                evicted = frames[slot]
                frames[slot] = page

            steps.append(Step(page, frames, not hit, faults, evicted))

        return steps

    @staticmethod
    def count_faults(steps):
        return sum(1 for s in steps if s.is_fault)


# ================================================================
#  FILE HANDLER
# ================================================================
class FileHandler:
    @staticmethod
    def read_input(path):
        """
        Doc file CSV dau vao.
        Dong 1: frame size
        Dong 2: reference string
        """
        with open(path, "r", encoding="utf-8-sig") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        if len(lines) < 2:
            raise ValueError("File CSV thieu du lieu (can it nhat 2 dong).")

        frame_size = int(lines[0])
        if frame_size <= 0 or frame_size > 20:
            raise ValueError(f"Frame size khong hop le: {frame_size} (can tu 1-20).")

        tokens = lines[1].split(",")
        ref_string = []
        for t in tokens:
            t = t.strip()
            if not t:
                continue
            val = int(t)
            if val < 0:
                raise ValueError(f"So trang am khong hop le: {val}")
            ref_string.append(val)

        if not ref_string:
            raise ValueError("Reference string trong.")

        return frame_size, ref_string

    @staticmethod
    def write_output(path, algo_name, frame_size, ref_string, steps, exec_ms):
        """
        Xuat ket qua ra CSV.
        Format: Step | Page | Fault/Hit | Evicted | Frame_1..N | Total_Faults | Total_Hits
        """
        faults = sum(1 for s in steps if s.is_fault)
        hits   = len(steps) - faults
        hit_rate   = hits   / len(steps) * 100 if steps else 0
        fault_rate = faults / len(steps) * 100 if steps else 0

        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["=== VIRTUAL MEMORY PAGE REPLACEMENT SIMULATOR ==="])
            w.writerow(["OS_VME_08 - Group 5 - HCMUTRANS"])
            w.writerow([])
            w.writerow(["Algorithm",        algo_name])
            w.writerow(["Frame Size",        frame_size])
            w.writerow(["Total References",  len(ref_string)])
            w.writerow(["Total Faults",      faults])
            w.writerow(["Total Hits",        hits])
            w.writerow(["Hit Rate (%)",      f"{hit_rate:.2f}"])
            w.writerow(["Fault Rate (%)",    f"{fault_rate:.2f}"])
            w.writerow(["Exec Time (ms)",    f"{exec_ms:.3f}"])
            w.writerow([])
            w.writerow(["Reference String"] + ref_string)
            w.writerow([])

            # Header
            header = ["Step", "Page", "Fault/Hit", "Evicted"]
            header += [f"Frame_{i+1}" for i in range(frame_size)]
            header += ["Total_Faults", "Total_Hits"]
            w.writerow(header)

            tf, th = 0, 0
            for i, s in enumerate(steps):
                if s.is_fault: tf += 1
                else:          th += 1
                row = [
                    i + 1,
                    s.page,
                    "FAULT" if s.is_fault else "HIT",
                    s.evicted if s.evicted != -1 else "-"
                ]
                row += [s.frames[f] if f < len(s.frames) and s.frames[f] != -1 else "-"
                        for f in range(frame_size)]
                row += [tf, th]
                w.writerow(row)

    @staticmethod
    def create_sample(path):
        with open(path, "w", newline="") as f:
            f.write("3\n7,0,1,2,0,3,0,4,2,3,0,3\n")

    @staticmethod
    def create_belady(path):
        with open(path, "w", newline="") as f:
            f.write("4\n1,2,3,4,1,2,5,1,2,3,4,5\n")


# ================================================================
#  UNIT TESTS
# ================================================================
class TestRunner:
    """
    Kiem tra tinh dung dan cua 3 thuat toan theo giao trinh
    OS Concepts 10th Edition - Silberschatz et al.
    """
    def __init__(self):
        self.results = []
        self.passed  = 0
        self.failed  = 0

    def check(self, name, condition):
        ok = bool(condition)
        status = "PASS" if ok else "FAIL"
        self.results.append((status, name))
        if ok: self.passed += 1
        else:  self.failed  += 1

    def run_all(self):
        refs = [7,0,1,2,0,3,0,4,2,3,0,3]
        n    = 3

        sF = FIFO.run(refs, n)
        sL = LRU.run(refs, n)
        sO = OPT.run(refs, n)

        fF = FIFO.count_faults(sF)
        fL = LRU.count_faults(sL)
        fO = OPT.count_faults(sO)

        # Textbook verification
        self.check("FIFO = 9 faults  (OS Concepts 10e p.401)",  fF == 9)
        self.check("LRU  = 8 faults  (OS Concepts 10e p.403)",  fL == 8)
        self.check("OPT  = 6 faults  (OS Concepts 10e p.402)",  fO == 6)
        self.check("OPT <= LRU <= FIFO  (optimal property)",    fO <= fL <= fF)

        # Step count
        self.check("FIFO step count = ref length",   len(sF) == len(refs))
        self.check("LRU  step count = ref length",   len(sL) == len(refs))
        self.check("OPT  step count = ref length",   len(sO) == len(refs))

        # First access always fault
        self.check("FIFO step 1 is fault (page 7)",  sF[0].is_fault)
        self.check("LRU  step 1 is fault (page 7)",  sL[0].is_fault)
        self.check("OPT  step 1 is fault (page 7)",  sO[0].is_fault)

        # Step 5 (page 0) should be hit for all
        self.check("FIFO step 5 is hit  (page 0)",   not sF[4].is_fault)
        self.check("LRU  step 5 is hit  (page 0)",   not sL[4].is_fault)
        self.check("OPT  step 5 is hit  (page 0)",   not sO[4].is_fault)

        # Empty ref string
        sEmpty = FIFO.run([], 3)
        self.check("FIFO: empty ref string -> 0 steps",  len(sEmpty) == 0)

        # Single frame
        s1 = FIFO.run([1,1,1,2,2], 1)
        self.check("FIFO: frame=1, refs=1,1,1,2,2 -> 2 faults",
                   FIFO.count_faults(s1) == 2)

        # Belady's Anomaly
        belady = [1,2,3,4,1,2,5,1,2,3,4,5]
        f3 = FIFO.count_faults(FIFO.run(belady, 3))
        f4 = FIFO.count_faults(FIFO.run(belady, 4))
        self.check("Belady: FIFO 3 frames = 9 faults",          f3 == 9)
        self.check("Belady: FIFO 4 frames = 10 faults (anomaly!)", f4 == 10)
        self.check("Belady anomaly confirmed (more frames > more faults)", f4 > f3)

        return self.results, self.passed, self.failed


# ================================================================
#  MAIN GUI APPLICATION
# ================================================================
class App(tk.Tk):
    # Color palette
    BG       = "#1e1e2e"
    BG2      = "#2a2a3e"
    BG3      = "#313145"
    ACCENT   = "#7c8cf8"
    FAULT    = "#f38ba8"
    HIT      = "#a6e3a1"
    NEW_PAGE = "#89b4fa"
    TEXT     = "#cdd6f4"
    TEXT2    = "#6c7086"
    YELLOW   = "#f9e2af"
    BORDER   = "#45475a"
    WHITE    = "#ffffff"

    def __init__(self):
        super().__init__()
        self.title("Virtual Memory Page Replacement Simulator — OS_VME_08 Group 5")
        self.geometry("1280x820")
        self.minsize(1100, 700)
        self.configure(bg=self.BG)
        self.resizable(True, True)

        # State
        self.frame_size  = tk.IntVar(value=3)
        self.ref_string  = []
        self.last_steps  = []
        self.last_algo   = ""
        self.last_exec   = 0.0
        self.input_path  = ""

        # Create sample inputs
        os.makedirs("input",  exist_ok=True)
        os.makedirs("output", exist_ok=True)
        if not os.path.exists("input/input.csv"):
            FileHandler.create_sample("input/input.csv")
        if not os.path.exists("input/belady_test.csv"):
            FileHandler.create_belady("input/belady_test.csv")

        self._load_default()
        self._build_ui()

    # ---- Load default input ------------------------------------
    def _load_default(self):
        try:
            fs, rs = FileHandler.read_input("input/input.csv")
            self.frame_size.set(fs)
            self.ref_string = rs
            self.input_path = "input/input.csv"
        except Exception:
            self.frame_size.set(3)
            self.ref_string = [7,0,1,2,0,3,0,4,2,3,0,3]

    # ---- Build UI ----------------------------------------------
    def _build_ui(self):
        self._build_header()
        self._build_body()
        self._build_status()

    def _build_header(self):
        hf = tk.Frame(self, bg=self.BG2, pady=10)
        hf.pack(fill="x")

        tk.Label(hf, text="Virtual Memory Page Replacement Simulator",
                 font=("Consolas", 18, "bold"),
                 bg=self.BG2, fg=self.ACCENT).pack()
        tk.Label(hf, text="OS_VME_08  ·  Group 5  ·  HCMUTRANS  ·  FIFO | LRU | OPT",
                 font=("Consolas", 10),
                 bg=self.BG2, fg=self.TEXT2).pack()

    def _build_body(self):
        body = tk.Frame(self, bg=self.BG)
        body.pack(fill="both", expand=True, padx=0, pady=0)

        # Left panel
        left = tk.Frame(body, bg=self.BG2, width=300)
        left.pack(side="left", fill="y", padx=(10,5), pady=10)
        left.pack_propagate(False)
        self._build_left(left)

        # Right panel
        right = tk.Frame(body, bg=self.BG)
        right.pack(side="left", fill="both", expand=True, padx=(5,10), pady=10)
        self._build_right(right)

    # ---- LEFT PANEL --------------------------------------------
    def _build_left(self, parent):
        def section(text):
            tk.Label(parent, text=text, font=("Consolas", 9, "bold"),
                     bg=self.BG2, fg=self.TEXT2).pack(anchor="w", padx=12, pady=(14,2))

        def hline():
            tk.Frame(parent, bg=self.BORDER, height=1).pack(fill="x", padx=8, pady=2)

        # Title
        tk.Label(parent, text="⚙  Configuration",
                 font=("Consolas", 12, "bold"),
                 bg=self.BG2, fg=self.WHITE).pack(pady=(14,4))
        hline()

        # --- Input file ---
        section("INPUT FILE")
        self.file_label = tk.Label(parent, text="input/input.csv",
                                   font=("Consolas", 9), bg=self.BG3,
                                   fg=self.YELLOW, wraplength=260, justify="left",
                                   padx=8, pady=4)
        self.file_label.pack(fill="x", padx=8, pady=2)
        tk.Button(parent, text="Load CSV file",
                  command=self._load_csv,
                  font=("Consolas", 10), bg=self.BG3,
                  fg=self.ACCENT, activebackground=self.BG,
                  relief="flat", cursor="hand2", pady=5).pack(fill="x", padx=8, pady=2)

        # --- Frame size ---
        section("FRAME SIZE")
        row = tk.Frame(parent, bg=self.BG2)
        row.pack(fill="x", padx=8)
        self.frame_slider = tk.Scale(row, from_=1, to=10,
                                     variable=self.frame_size,
                                     orient="horizontal",
                                     bg=self.BG2, fg=self.TEXT,
                                     highlightthickness=0,
                                     troughcolor=self.BG3,
                                     activebackground=self.ACCENT,
                                     font=("Consolas", 9))
        self.frame_slider.pack(side="left", fill="x", expand=True)
        self.frame_val = tk.Label(row, textvariable=self.frame_size,
                                  width=3, font=("Consolas", 12, "bold"),
                                  bg=self.BG2, fg=self.YELLOW)
        self.frame_val.pack(side="left", padx=4)

        # --- Reference string ---
        section("REFERENCE STRING")
        self.ref_entry = tk.Text(parent, height=3, width=28,
                                 font=("Consolas", 10), bg=self.BG3,
                                 fg=self.TEXT, insertbackground=self.TEXT,
                                 relief="flat", padx=6, pady=4)
        self.ref_entry.pack(fill="x", padx=8, pady=2)
        self.ref_entry.insert("1.0", ",".join(map(str, self.ref_string)))

        tk.Label(parent, text="Comma-separated page numbers",
                 font=("Consolas", 8), bg=self.BG2, fg=self.TEXT2).pack(anchor="w", padx=12)

        hline()

        # --- Algorithm buttons ---
        section("RUN ALGORITHM")
        for label, algo, color in [
            ("▶  Run FIFO",  "FIFO",  "#89b4fa"),
            ("▶  Run LRU",   "LRU",   "#a6e3a1"),
            ("▶  Run OPT",   "OPT",   "#cba6f7"),
        ]:
            tk.Button(parent, text=label,
                      command=lambda a=algo: self._run(a),
                      font=("Consolas", 11, "bold"),
                      bg=self.BG3, fg=color,
                      activebackground=self.BG,
                      relief="flat", cursor="hand2", pady=7).pack(fill="x", padx=8, pady=3)

        tk.Button(parent, text="⚡  Run ALL & Compare",
                  command=self._run_all,
                  font=("Consolas", 11, "bold"),
                  bg=self.ACCENT, fg=self.BG,
                  activebackground="#5c6bc0",
                  relief="flat", cursor="hand2", pady=8).pack(fill="x", padx=8, pady=4)

        hline()

        # --- Export ---
        section("EXPORT")
        tk.Button(parent, text="💾  Export output.csv",
                  command=self._export,
                  font=("Consolas", 10), bg=self.BG3,
                  fg=self.YELLOW, activebackground=self.BG,
                  relief="flat", cursor="hand2", pady=6).pack(fill="x", padx=8, pady=2)

        tk.Button(parent, text="🧪  Run Unit Tests",
                  command=self._run_tests,
                  font=("Consolas", 10), bg=self.BG3,
                  fg="#f9e2af", activebackground=self.BG,
                  relief="flat", cursor="hand2", pady=6).pack(fill="x", padx=8, pady=2)

        tk.Button(parent, text="👥  Team Info",
                  command=self._show_team,
                  font=("Consolas", 10), bg=self.BG3,
                  fg=self.TEXT2, activebackground=self.BG,
                  relief="flat", cursor="hand2", pady=6).pack(fill="x", padx=8, pady=2)

    # ---- RIGHT PANEL -------------------------------------------
    def _build_right(self, parent):
        # Tabs
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook",
                         background=self.BG, borderwidth=0)
        style.configure("TNotebook.Tab",
                         background=self.BG3, foreground=self.TEXT2,
                         font=("Consolas", 10, "bold"),
                         padding=[14, 6])
        style.map("TNotebook.Tab",
                  background=[("selected", self.ACCENT)],
                  foreground=[("selected", self.BG)])

        self.nb = ttk.Notebook(parent)
        self.nb.pack(fill="both", expand=True)

        # Tab 1: Gantt
        self.tab_gantt = tk.Frame(self.nb, bg=self.BG)
        self.nb.add(self.tab_gantt, text="  Gantt Chart  ")
        self._build_gantt_tab(self.tab_gantt)

        # Tab 2: Compare
        self.tab_compare = tk.Frame(self.nb, bg=self.BG)
        self.nb.add(self.tab_compare, text="  Comparison  ")
        self._build_compare_tab(self.tab_compare)

        # Tab 3: Stats
        self.tab_stats = tk.Frame(self.nb, bg=self.BG)
        self.nb.add(self.tab_stats, text="  Statistics  ")
        self._build_stats_tab(self.tab_stats)

    def _build_gantt_tab(self, parent):
        # Algo label
        self.gantt_title = tk.Label(parent,
                                    text="Select an algorithm and click Run",
                                    font=("Consolas", 12, "bold"),
                                    bg=self.BG, fg=self.TEXT2)
        self.gantt_title.pack(pady=(10,4))

        # Stat pills row
        pills = tk.Frame(parent, bg=self.BG)
        pills.pack(pady=(0,8))

        self.lbl_faults = self._pill(pills, "—", "Page Faults", self.FAULT)
        self.lbl_hits   = self._pill(pills, "—", "Page Hits",   self.HIT)
        self.lbl_rate   = self._pill(pills, "—", "Hit Rate",    self.ACCENT)
        self.lbl_time   = self._pill(pills, "—", "Exec Time",   self.YELLOW)

        # Legend
        leg = tk.Frame(parent, bg=self.BG)
        leg.pack(pady=(0,6))
        for color, label in [
            (self.FAULT,    "Page Fault"),
            (self.HIT,      "Page Hit"),
            (self.NEW_PAGE, "New Frame"),
            (self.BG3,      "Unchanged"),
        ]:
            dot = tk.Frame(leg, bg=color, width=12, height=12)
            dot.pack(side="left", padx=(10,3))
            tk.Label(leg, text=label, font=("Consolas", 9),
                     bg=self.BG, fg=self.TEXT2).pack(side="left", padx=(0,8))

        # Scrollable gantt canvas
        frame_wrap = tk.Frame(parent, bg=self.BORDER, bd=1)
        frame_wrap.pack(fill="both", expand=True, padx=10, pady=(0,10))

        self.gantt_canvas = tk.Canvas(frame_wrap, bg=self.BG2,
                                      highlightthickness=0)
        hbar = tk.Scrollbar(frame_wrap, orient="horizontal",
                            command=self.gantt_canvas.xview)
        vbar = tk.Scrollbar(frame_wrap, orient="vertical",
                            command=self.gantt_canvas.yview)
        self.gantt_canvas.configure(xscrollcommand=hbar.set,
                                    yscrollcommand=vbar.set)
        hbar.pack(side="bottom", fill="x")
        vbar.pack(side="right",  fill="y")
        self.gantt_canvas.pack(fill="both", expand=True)

    def _build_compare_tab(self, parent):
        tk.Label(parent, text="Algorithm Comparison",
                 font=("Consolas", 13, "bold"),
                 bg=self.BG, fg=self.WHITE).pack(pady=(14,4))
        tk.Label(parent, text='Click "Run ALL & Compare" to see comparison',
                 font=("Consolas", 10),
                 bg=self.BG, fg=self.TEXT2).pack()

        self.compare_frame = tk.Frame(parent, bg=self.BG)
        self.compare_frame.pack(fill="both", expand=True, padx=20, pady=10)

    def _build_stats_tab(self, parent):
        tk.Label(parent, text="Proof of Correctness",
                 font=("Consolas", 13, "bold"),
                 bg=self.BG, fg=self.WHITE).pack(pady=(14,2))
        tk.Label(parent,
                 text="Results compared with OS Concepts 10th Edition — Silberschatz et al.",
                 font=("Consolas", 9), bg=self.BG, fg=self.TEXT2).pack()

        self.stats_frame = tk.Frame(parent, bg=self.BG)
        self.stats_frame.pack(fill="both", expand=True, padx=20, pady=10)

    # ---- Helper: stat pill -------------------------------------
    def _pill(self, parent, val, label, color):
        f = tk.Frame(parent, bg=self.BG3, padx=14, pady=6)
        f.pack(side="left", padx=6)
        v = tk.Label(f, text=val, font=("Consolas", 18, "bold"),
                     bg=self.BG3, fg=color)
        v.pack()
        tk.Label(f, text=label, font=("Consolas", 9),
                 bg=self.BG3, fg=self.TEXT2).pack()
        return v

    # ---- Status bar --------------------------------------------
    def _build_status(self):
        self.status_var = tk.StringVar(value="Ready  |  OS_VME_08 Group 5  |  HCMUTRANS")
        sb = tk.Label(self, textvariable=self.status_var,
                      font=("Consolas", 9), bg=self.BG3,
                      fg=self.TEXT2, anchor="w", padx=12, pady=4)
        sb.pack(fill="x", side="bottom")

    def _set_status(self, msg):
        self.status_var.set(msg)
        self.update_idletasks()

    # ---- Load CSV ----------------------------------------------
    def _load_csv(self):
        path = filedialog.askopenfilename(
            title="Select input CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            fs, rs = FileHandler.read_input(path)
            self.frame_size.set(fs)
            self.ref_string = rs
            self.input_path = path
            self.file_label.config(text=os.path.basename(path))
            self.ref_entry.delete("1.0", "end")
            self.ref_entry.insert("1.0", ",".join(map(str, rs)))
            self._set_status(f"Loaded: {path}  |  {len(rs)} pages  |  {fs} frames")
        except Exception as e:
            messagebox.showerror("Load Error", str(e))

    # ---- Parse ref string from entry ---------------------------
    def _parse_ref(self):
        raw = self.ref_entry.get("1.0", "end").strip()
        tokens = [t.strip() for t in raw.split(",") if t.strip()]
        result = []
        for t in tokens:
            try:
                v = int(t)
                if v < 0:
                    raise ValueError(f"So trang am: {v}")
                result.append(v)
            except ValueError as e:
                raise ValueError(f"Reference string khong hop le: {e}")
        if not result:
            raise ValueError("Reference string trong.")
        return result

    # ---- Run single algorithm ----------------------------------
    def _run(self, algo_name):
        try:
            refs = self._parse_ref()
            n    = self.frame_size.get()
        except ValueError as e:
            messagebox.showerror("Input Error", str(e)); return

        self.ref_string = refs
        self._set_status(f"Running {algo_name}...")

        algos = {"FIFO": FIFO, "LRU": LRU, "OPT": OPT}
        colors = {"FIFO": self.NEW_PAGE, "LRU": self.HIT, "OPT": "#cba6f7"}

        t0 = time.perf_counter()
        steps = algos[algo_name].run(refs, n)
        elapsed = (time.perf_counter() - t0) * 1000

        self.last_steps = steps
        self.last_algo  = algo_name
        self.last_exec  = elapsed

        self._draw_gantt(algo_name, steps, n, colors[algo_name])
        self._update_stats_tab(algo_name, steps, refs, n)
        self.nb.select(0)
        self._set_status(
            f"{algo_name}  |  {sum(1 for s in steps if s.is_fault)} faults  "
            f"|  {len(steps)-sum(1 for s in steps if s.is_fault)} hits  "
            f"|  {elapsed:.3f} ms"
        )

    # ---- Run all & compare -------------------------------------
    def _run_all(self):
        try:
            refs = self._parse_ref()
            n    = self.frame_size.get()
        except ValueError as e:
            messagebox.showerror("Input Error", str(e)); return

        self.ref_string = refs
        self._set_status("Running all algorithms...")

        results = {}
        times   = {}
        for AlgoCls, name in [(FIFO,"FIFO"),(LRU,"LRU"),(OPT,"OPT")]:
            t0 = time.perf_counter()
            results[name] = AlgoCls.run(refs, n)
            times[name]   = (time.perf_counter() - t0) * 1000

        # Show FIFO gantt by default
        self.last_steps = results["OPT"]
        self.last_algo  = "OPT"
        self.last_exec  = times["OPT"]

        self._draw_gantt("ALL (showing OPT)", results["OPT"], n, "#cba6f7")
        self._draw_comparison(results, times, refs, n)
        self._update_stats_tab("ALL", results["OPT"], refs, n)
        self.nb.select(1)  # Switch to comparison tab
        self._set_status("All algorithms done. See Comparison tab.")

    # ---- Draw Gantt --------------------------------------------
    def _draw_gantt(self, algo_name, steps, n, header_color):
        c = self.gantt_canvas
        c.delete("all")

        if not steps:
            c.create_text(300, 100, text="No data", fill=self.TEXT2,
                          font=("Consolas", 12))
            return

        CELL_W = 44
        CELL_H = 36
        LABEL_W = 90
        PAD_TOP = 20
        PAD_LEFT = 10

        rows = n + 3  # header + n frames + F/H row
        cols = len(steps)

        total_w = PAD_LEFT + LABEL_W + cols * CELL_W + 20
        total_h = PAD_TOP + rows * CELL_H + 20
        c.configure(scrollregion=(0, 0, total_w, total_h))

        # Update pills
        faults = sum(1 for s in steps if s.is_fault)
        hits   = len(steps) - faults
        hr     = hits / len(steps) * 100
        self.lbl_faults.config(text=str(faults))
        self.lbl_hits.config(text=str(hits))
        self.lbl_rate.config(text=f"{hr:.1f}%")
        self.lbl_time.config(text=f"{self.last_exec:.2f}ms")
        self.gantt_title.config(text=f"Algorithm: {algo_name}",
                                fg=header_color)

        def cell(col, row, text, bg, fg="#ffffff", bold=False):
            x0 = PAD_LEFT + LABEL_W + col * CELL_W
            y0 = PAD_TOP  + row * CELL_H
            x1, y1 = x0 + CELL_W - 1, y0 + CELL_H - 1
            c.create_rectangle(x0, y0, x1, y1, fill=bg, outline=self.BORDER, width=1)
            font = ("Consolas", 10, "bold") if bold else ("Consolas", 10)
            c.create_text((x0+x1)//2, (y0+y1)//2,
                          text=str(text), fill=fg, font=font)

        def row_label(row, text):
            y0 = PAD_TOP + row * CELL_H
            y1 = y0 + CELL_H
            c.create_rectangle(PAD_LEFT, y0, PAD_LEFT+LABEL_W-1, y1,
                                fill=self.BG3, outline=self.BORDER)
            c.create_text(PAD_LEFT + LABEL_W//2, (y0+y1)//2,
                          text=text, fill=self.TEXT2,
                          font=("Consolas", 9))

        # Row labels
        row_label(0, "Page Ref")
        for f in range(n):
            row_label(f+1, f"Frame {f+1}")
        row_label(n+1, "Fault / Hit")

        # Step number row (above cells)
        for i, s in enumerate(steps):
            x0 = PAD_LEFT + LABEL_W + i * CELL_W
            c.create_text(x0 + CELL_W//2, PAD_TOP//2 + 4,
                          text=str(i+1), fill=self.TEXT2,
                          font=("Consolas", 8))

        # Page row
        for i, s in enumerate(steps):
            bg = self.FAULT if s.is_fault else self.HIT
            fg = self.BG
            cell(i, 0, s.page, bg, fg, bold=True)

        # Frame rows
        for f in range(n):
            for i, s in enumerate(steps):
                if f < len(s.frames) and s.frames[f] != -1:
                    is_new = s.is_fault and s.frames[f] == s.page
                    bg = self.NEW_PAGE if is_new else self.BG3
                    fg = self.BG if is_new else self.TEXT
                    cell(i, f+1, s.frames[f], bg, fg)
                else:
                    cell(i, f+1, "·", self.BG2, self.TEXT2)

        # F/H row
        for i, s in enumerate(steps):
            bg = self.FAULT if s.is_fault else self.HIT
            cell(i, n+1, "F" if s.is_fault else "H", bg, self.BG, bold=True)

    # ---- Draw Comparison Tab -----------------------------------
    def _draw_comparison(self, results, times, refs, n):
        for w in self.compare_frame.winfo_children():
            w.destroy()

        faults = {name: sum(1 for s in steps if s.is_fault)
                  for name, steps in results.items()}
        hits   = {name: len(refs) - faults[name] for name in faults}
        rates  = {name: hits[name] / len(refs) * 100 for name in faults}
        max_f  = max(faults.values()) or 1

        colors = {"FIFO": self.NEW_PAGE, "LRU": self.HIT, "OPT": "#cba6f7"}

        # Header
        tk.Label(self.compare_frame,
                 text=f"Input: {len(refs)} pages  |  {n} frames",
                 font=("Consolas", 11), bg=self.BG, fg=self.TEXT2).pack(pady=(0,14))

        # Bar charts
        for name in ["FIFO", "LRU", "OPT"]:
            row = tk.Frame(self.compare_frame, bg=self.BG)
            row.pack(fill="x", pady=6)

            tk.Label(row, text=name, width=6,
                     font=("Consolas", 13, "bold"),
                     bg=self.BG, fg=colors[name]).pack(side="left")

            # Bar
            bar_frame = tk.Frame(row, bg=self.BORDER, height=32, width=500)
            bar_frame.pack(side="left", padx=10)
            bar_frame.pack_propagate(False)
            fill_w = int(faults[name] / max_f * 498)
            tk.Frame(bar_frame, bg=colors[name],
                     width=fill_w, height=30).place(x=1, y=1)

            # Stats
            info = (f"  {faults[name]} faults  |  "
                    f"{hits[name]} hits  |  "
                    f"{rates[name]:.1f}% hit rate  |  "
                    f"{times[name]:.3f} ms")
            tk.Label(row, text=info, font=("Consolas", 10),
                     bg=self.BG, fg=self.TEXT).pack(side="left")

        # Winner
        best_name = min(faults, key=faults.get)
        tk.Frame(self.compare_frame, bg=self.BORDER, height=1).pack(fill="x", pady=14)
        tk.Label(self.compare_frame,
                 text=f"✓  Best algorithm: {best_name}  ({faults[best_name]} faults)",
                 font=("Consolas", 13, "bold"),
                 bg=self.BG, fg=colors[best_name]).pack()

        # Belady note
        if faults["FIFO"] > faults["OPT"]:
            tk.Label(self.compare_frame,
                     text="⚠  FIFO may exhibit Belady's Anomaly with certain inputs",
                     font=("Consolas", 10),
                     bg=self.BG, fg=self.YELLOW).pack(pady=4)

        # Table
        tk.Frame(self.compare_frame, bg=self.BORDER, height=1).pack(fill="x", pady=10)
        hdr = tk.Frame(self.compare_frame, bg=self.BG)
        hdr.pack(fill="x")
        for col, w in [("Algorithm",14),("Faults",10),("Hits",10),
                       ("Hit Rate",12),("Exec (ms)",12)]:
            tk.Label(hdr, text=col, width=w,
                     font=("Consolas", 10, "bold"),
                     bg=self.BG3, fg=self.ACCENT,
                     relief="flat", pady=4).pack(side="left", padx=1)

        for name in ["FIFO","LRU","OPT"]:
            row2 = tk.Frame(self.compare_frame, bg=self.BG)
            row2.pack(fill="x", pady=1)
            for val, w in [
                (name,            14),
                (faults[name],    10),
                (hits[name],      10),
                (f"{rates[name]:.1f}%", 12),
                (f"{times[name]:.3f}", 12),
            ]:
                tk.Label(row2, text=str(val), width=w,
                         font=("Consolas", 10),
                         bg=self.BG2, fg=colors[name],
                         relief="flat", pady=4).pack(side="left", padx=1)

    # ---- Stats / Proof tab -------------------------------------
    def _update_stats_tab(self, algo_name, steps, refs, n):
        for w in self.stats_frame.winfo_children():
            w.destroy()

        # Textbook proof section
        proof_frame = tk.LabelFrame(self.stats_frame,
                                    text="  Proof vs OS Concepts 10th Edition  ",
                                    font=("Consolas", 10, "bold"),
                                    bg=self.BG, fg=self.ACCENT,
                                    labelanchor="nw", relief="flat",
                                    bd=1)
        proof_frame.pack(fill="x", pady=(0,10))

        tb_refs = [7,0,1,2,0,3,0,4,2,3,0,3]
        tb_n    = 3
        expected = {"FIFO": 9, "LRU": 8, "OPT": 6}
        algos_map = {"FIFO": FIFO, "LRU": LRU, "OPT": OPT}

        hdr = tk.Frame(proof_frame, bg=self.BG)
        hdr.pack(fill="x", padx=8, pady=(8,2))
        for col, wid in [("Algorithm",12),("Expected",12),("Got",8),("Status",10)]:
            tk.Label(hdr, text=col, width=wid,
                     font=("Consolas", 10, "bold"),
                     bg=self.BG3, fg=self.TEXT2,
                     pady=3).pack(side="left", padx=1)

        for name, exp in expected.items():
            got = algos_map[name].count_faults(algos_map[name].run(tb_refs, tb_n))
            ok  = got == exp
            row = tk.Frame(proof_frame, bg=self.BG)
            row.pack(fill="x", padx=8, pady=1)
            color = self.HIT if ok else self.FAULT
            for val, wid in [
                (name, 12), (f"{exp} faults", 12),
                (str(got), 8),
                ("✓ PASS" if ok else "✗ FAIL", 10)
            ]:
                tk.Label(row, text=str(val), width=wid,
                         font=("Consolas", 10),
                         bg=self.BG2,
                         fg=color if val in (str(got), "✓ PASS", "✗ FAIL") else self.TEXT,
                         pady=3).pack(side="left", padx=1)

        tk.Label(proof_frame,
                 text="Reference: 7,0,1,2,0,3,0,4,2,3,0,3  |  3 frames  |  (p.400-403)",
                 font=("Consolas", 8), bg=self.BG, fg=self.TEXT2).pack(padx=8, pady=(2,8))

        # Current run stats
        if steps:
            faults = sum(1 for s in steps if s.is_fault)
            hits   = len(steps) - faults

            cur = tk.LabelFrame(self.stats_frame,
                                text=f"  Current Run: {algo_name}  ",
                                font=("Consolas", 10, "bold"),
                                bg=self.BG, fg=self.YELLOW,
                                labelanchor="nw", relief="flat", bd=1)
            cur.pack(fill="x")
            for label, val, color in [
                ("Total References", len(steps),        self.TEXT),
                ("Frame Size",       n,                 self.TEXT),
                ("Page Faults",      faults,            self.FAULT),
                ("Page Hits",        hits,              self.HIT),
                ("Hit Rate",         f"{hits/len(steps)*100:.2f}%", self.ACCENT),
                ("Fault Rate",       f"{faults/len(steps)*100:.2f}%", self.FAULT),
                ("Exec Time",        f"{self.last_exec:.3f} ms",    self.YELLOW),
            ]:
                r = tk.Frame(cur, bg=self.BG)
                r.pack(fill="x", padx=8, pady=1)
                tk.Label(r, text=label, width=20, anchor="w",
                         font=("Consolas", 10), bg=self.BG,
                         fg=self.TEXT2).pack(side="left")
                tk.Label(r, text=str(val),
                         font=("Consolas", 10, "bold"),
                         bg=self.BG, fg=color).pack(side="left")

    # ---- Export ------------------------------------------------
    def _export(self):
        if not self.last_steps:
            messagebox.showwarning("Export", "No results yet. Run an algorithm first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=f"output_{self.last_algo}.csv",
            filetypes=[("CSV files","*.csv")]
        )
        if not path:
            return
        try:
            refs = self._parse_ref()
            FileHandler.write_output(path, self.last_algo,
                                     self.frame_size.get(),
                                     refs, self.last_steps, self.last_exec)
            messagebox.showinfo("Export", f"Saved to:\n{path}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    # ---- Unit tests --------------------------------------------
    def _run_tests(self):
        win = tk.Toplevel(self)
        win.title("Unit Tests — OS_VME_08 Group 5")
        win.geometry("600x520")
        win.configure(bg=self.BG)

        tk.Label(win, text="Unit Test Results",
                 font=("Consolas", 13, "bold"),
                 bg=self.BG, fg=self.ACCENT).pack(pady=(14,4))
        tk.Label(win, text="Verified against OS Concepts 10th Ed.",
                 font=("Consolas", 9), bg=self.BG, fg=self.TEXT2).pack()

        frame = tk.Frame(win, bg=self.BG)
        frame.pack(fill="both", expand=True, padx=16, pady=10)

        tr = TestRunner()
        results, passed, failed = tr.run_all()

        for status, name in results:
            row = tk.Frame(frame, bg=self.BG)
            row.pack(fill="x", pady=2)
            color = self.HIT if status == "PASS" else self.FAULT
            tk.Label(row, text=f"[{status}]", width=7,
                     font=("Consolas", 10, "bold"),
                     bg=self.BG2, fg=color).pack(side="left", padx=(0,6))
            tk.Label(row, text=name,
                     font=("Consolas", 10),
                     bg=self.BG, fg=self.TEXT).pack(side="left")

        tk.Frame(win, bg=self.BORDER, height=1).pack(fill="x", padx=16)
        summary_color = self.HIT if failed == 0 else self.FAULT
        tk.Label(win,
                 text=f"Passed: {passed}  |  Failed: {failed}  |  Total: {passed+failed}",
                 font=("Consolas", 11, "bold"),
                 bg=self.BG, fg=summary_color).pack(pady=10)

    # ---- Team info ---------------------------------------------
    def _show_team(self):
        win = tk.Toplevel(self)
        win.title("Team Info — OS_VME_08 Group 5")
        win.geometry("540x400")
        win.configure(bg=self.BG)

        tk.Label(win, text="OS_VME_08 — Nhóm 5",
                 font=("Consolas", 14, "bold"),
                 bg=self.BG, fg=self.ACCENT).pack(pady=(14,2))
        tk.Label(win, text="Đại học Giao thông Vận tải TP.HCM  |  Mã lớp: 7480201390613",
                 font=("Consolas", 9), bg=self.BG, fg=self.TEXT2).pack()

        tk.Frame(win, bg=self.BORDER, height=1).pack(fill="x", padx=16, pady=10)

        members = [
            ("Phan Đình Phát",        "060206002816", "Algorithm Developer"),
            ("Nguyễn Thị Xuân Tuyền", "054306001845", "Data & File Handler"),
            ("Nguyễn Thanh Tuấn",     "051206002660", "GUI Developer"),
            ("Dương Trọng Nghĩa",     "066206008908", "Tester & Integrator"),
            ("Kim Nhựt Hoàng",        "084206006510", "Documentation"),
        ]
        for i, (name, sid, role) in enumerate(members, 1):
            row = tk.Frame(win, bg=self.BG2 if i%2==0 else self.BG)
            row.pack(fill="x", padx=16, pady=1)
            tk.Label(row, text=f"{i}.", width=3,
                     font=("Consolas", 10, "bold"),
                     bg=row["bg"], fg=self.ACCENT).pack(side="left", padx=(8,0))
            tk.Label(row, text=name, width=24, anchor="w",
                     font=("Consolas", 10, "bold"),
                     bg=row["bg"], fg=self.YELLOW).pack(side="left")
            tk.Label(row, text=sid, width=14,
                     font=("Consolas", 9),
                     bg=row["bg"], fg=self.TEXT2).pack(side="left")
            tk.Label(row, text=role,
                     font=("Consolas", 9),
                     bg=row["bg"], fg=self.HIT).pack(side="left", padx=8)

        tk.Frame(win, bg=self.BORDER, height=1).pack(fill="x", padx=16, pady=10)
        tk.Label(win,
                 text="Ref: OS Concepts 10th Ed. — Silberschatz, Galvin, Gagne",
                 font=("Consolas", 9), bg=self.BG, fg=self.TEXT2).pack()


# ================================================================
#  ENTRY POINT
# ================================================================
if __name__ == "__main__":
    app = App()
    app.mainloop()
