@echo off
echo Starting Virtual Memory Page Replacement Simulator...
echo OS_VME_08 - Group 5 - HCMUTRANS
echo.
python main.py
if errorlevel 1 (
    echo.
    echo ERROR: Python not found. Please install Python 3.8+
    echo Download: https://www.python.org/downloads/
    pause
)
